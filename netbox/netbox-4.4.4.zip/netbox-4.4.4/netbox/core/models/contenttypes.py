# TODO: Remove this module in NetBox v4.5
# Provided for backward compatibility
from .object_types import *
